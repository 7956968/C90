/**
    UI window control related API.

    UI  window control export variables and function prototypes.

    @file       UICtrlWndLib.h
    @ingroup    mIUIControl
    @note       Nothing (or anything need to be mentioned).

    Copyright   Novatek Microelectronics Corp. 2011.  All rights reserved.
*/
#ifndef UICTRLWNDLIB_H
#define UICTRLWNDLIB_H
#endif
