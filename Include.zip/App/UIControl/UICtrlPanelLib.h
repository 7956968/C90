/**
    UI panel control related API.

    UI panel control export variables and function prototypes.

    @file       UICtrlPanelLib.h
    @ingroup    mIUIControl
    @note       Nothing (or anything need to be mentioned).

    Copyright   Novatek Microelectronics Corp. 2011.  All rights reserved.
*/

#ifndef UICTRLPANELLIB_H
#define UICTRLPANELLIB_H
#endif
