#ifndef _NVT_LIBC_WCHAR_H
#define _NVT_LIBC_WCHAR_H

#include <stddef.h>

extern size_t   wcslen(const wchar_t *wcs);

#endif
