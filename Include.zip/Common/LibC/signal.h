#ifndef _NVT_LIBC_SIGNAL_H
#define _NVT_LIBC_SIGNAL_H

extern int raise(int sig);

#endif
