#ifndef _GPROF_H_
#define _GPROF_H_

extern void gprof_InstallCmd(void);

#endif _GPROF_H_