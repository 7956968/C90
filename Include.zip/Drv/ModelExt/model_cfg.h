#ifndef _MODEL_CFG_H
#define _MODEL_CFG_H

#define MODEL_CFG_VER    0x16072510 ///< YYYY/MM/DD HH

//No data structure, just a string.

#endif
