#ifndef _DXGPS_H_
#define _DXGPS_H_

extern void DrvGPS_SetUartPort(void);

#endif

