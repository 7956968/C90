#ifndef _DXGSENSOR_H_
#define _DXGSENSOR_H_

#include "Type.h"
#include "i2c.h"

extern PI2C_OBJ DrvGSensor_GetI2cObj(void);

#endif

