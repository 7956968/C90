
extern void ecos_main(void);