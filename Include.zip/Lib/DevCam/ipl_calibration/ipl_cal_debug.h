#ifndef _IPL_CAL_DEBUG_H_
#define _IPL_CAL_DEBUG_H_
#define __MODULE__  IPL_CAL
#define __DBGLVL__          2 // 0=FATAL, 1=ERR, 2=WRN, 3=UNIT, 4=FUNC, 5=IND, 6=MSG, 7=VALUE, 8=USER
#define __DBGFLT__  "*"

#include "DebugModule.h"
#endif
