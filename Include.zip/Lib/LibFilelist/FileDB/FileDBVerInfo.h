/**
    Header file of FileDB version and build date information

    @file       FileDBVerInfo.h
    @ingroup    mILibFileDB

    Copyright   Novatek Microelectronics Corp. 2011.  All rights reserved.
*/
#ifndef _FILEDBVERINFO_H
#define _FILEDBVERINFO_H

#include "Type.h"


#endif



