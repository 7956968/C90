#ifndef _GXDISPLAY2_H
#define _GXDISPLAY2_H

#include "GxCommon.h"
#include "GxDisplay.h"
#include "DispDef.h"

#endif //_GXDISPLAY2_H
