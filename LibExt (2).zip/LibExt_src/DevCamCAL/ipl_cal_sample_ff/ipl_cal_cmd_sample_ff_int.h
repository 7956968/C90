/*
    IPL calibration ext cmd

    @file       ipl_cal_cmd_sample_ff_int.h
    @ingroup    mILibCal
    @note       Nothing.

    Copyright   Novatek Microelectronics Corp. 2017.  All rights reserved.
*/
#ifndef _CAL_CMD_SAMPLE_FF_INT_H
#define _CAL_CMD_SAMPLE_FF_INT_H

#include "ipl_cal_ext_common_int.h"

#if 0
- extern
#endif
extern IPL_CAL_EXT_LIB_TAB *IPL_CAL_SAMPLE_FF_EXT_LIB_TAB(void);

#endif
