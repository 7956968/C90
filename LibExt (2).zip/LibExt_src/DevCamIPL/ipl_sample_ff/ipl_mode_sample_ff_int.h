#ifndef _IPL_MODE_SAMPLE_FF_INT_H_
#define _IPL_MODE_SAMPLE_FF_INT_H_
/**
    ipl_mode_sample_ff_int.h


    @file       ipl_mode_sample_ff_int.h
    @ingroup    mISYSAlg
    @note       Nothing (or anything need to be mentioned).

    Copyright   Novatek Microelectronics Corp. 2011.  All rights reserved.
*/

#define RAW_ENC_BUF_RATIO 66    //%, minimum raw encode buffer ratio: 66
#endif //_IPL_MODE_SAMPLE_FF_INT_H_