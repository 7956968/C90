/**
    @file       ipl_fake.c

    @brief      dummy archive

    @note       Nothing (or anything need to be mentioned).

    Copyright   Novatek Microelectronics Corp. 2010.  All rights reserved.
*/
//----------------------------------------------------------------------------------------------------
#include "NvtVerInfo.h"
NVTVER_VERSION_ENTRY(IPL_FAKE, 1, 00, 000, 00)


//@@ EOF
