#ifndef _IPL_TP2825_FF_INT_H_
#define _IPL_TP2825_FF_INT_H_

#include "ipl_ext_common.h"
//tp2825
#include "ipl_obj_drv.h"
#include "ipl_mode_tp2825_ff_int.h"
#include "ipl_dzoom_tab_tp2825_ff_int.h"


#endif //_IPL_TP2825_FF_INT_H_
