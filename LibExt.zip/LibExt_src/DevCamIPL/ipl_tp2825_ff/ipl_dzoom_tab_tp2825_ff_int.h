#ifndef IPL_DZOOM_TAB_TP2825_FF_INT_H_
#define IPL_DZOOM_TAB_TP2825_FF_INT_H_
/**
    IPL_dzoomTabSample_Int.h


    @file       IPL_dzoomTabSample_Int.h
    @ingroup    mISYSAlg
    @note       Nothing (or anything need to be mentioned).

    Copyright   Novatek Microelectronics Corp. 2011.  All rights reserved.
*/


UINT32 *SenMode2TblFp_tp2825_ff(UINT32 id, UINT32 *DzMaxidx);
#endif //IPL_DZOOM_TAB_TP2825_FF_INT_H_

