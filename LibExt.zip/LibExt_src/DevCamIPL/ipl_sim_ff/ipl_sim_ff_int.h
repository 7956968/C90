#ifndef _IPL_SIM_FF_INT_H_
#define _IPL_SIM_FF_INT_H_

#include "ipl_ext_common.h"
//sample
#include "ipl_obj_drv.h"
#include "ipl_mode_sim_ff_int.h"
#include "ipl_dzoom_tab_sim_ff_int.h"


#endif //_IPL_SIM_FF_INT_H_
