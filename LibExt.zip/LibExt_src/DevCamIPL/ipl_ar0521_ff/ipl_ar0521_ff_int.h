#ifndef _IPL_AR0521_FF_INT_H_
#define _IPL_AR0521_FF_INT_H_

#include "ipl_ext_common.h"
//ar0521
#include "ipl_obj_drv.h"
#include "ipl_mode_ar0521_ff_int.h"
#include "ipl_dzoom_tab_ar0521_ff_int.h"


#endif //_IPL_AR0521_FF_INT_H_
