#ifndef _ALG_PHOTO_PHOTOFUNCINFO_H
#define _ALG_PHOTO_PHOTOFUNCINFO_H

extern void alg_Photo_InitPhotoFunc(PHOTO_FUNC_INFO *phead);

#endif
