#ifndef _ALG_MOVIESTAMP_H
#define _ALG_MOVIESTAMP_H

#include "GxImage.h"

extern void MovieStamp_DrawALG(UINT32 uiVidEncId, PIMG_BUF pDstImg);

#endif