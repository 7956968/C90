#ifndef _ALG_UIFLOWWNDMOVIE_H
#define _ALG_UIFLOWWNDMOVIE_H

extern INT32 UIFlowWndMovie_ALG_Draw_OSD(VControl *pCtrl, UINT32 paramNum, UINT32 *paramArray);
extern void  UIFlowWndMovie_ALG_Clear_OSD(void);
#endif
