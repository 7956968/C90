#ifndef _ALG_VDOOUT_H
#define _ALG_VDOOUT_H

#include "GxImage.h"
extern void alg_VdoOut_Draw(PIMG_BUF pDstImg);

#endif